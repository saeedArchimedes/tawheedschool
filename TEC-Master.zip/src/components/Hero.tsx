import React from 'react';
import { ArrowRight, Users, BookOpen, Award } from 'lucide-react';

interface HeroProps {
  onNavigate: (section: string) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="relative min-h-screen flex items-center">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://d64gsuwffb70l.cloudfront.net/68b71acf25bde7c300be169d_1756830460191_fada5f9c.webp')`
        }}
      />
      
      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Excellence in
            <span className="text-green-400 block">Islamic Education</span>
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
            Nurturing young minds with quality education rooted in Islamic values. 
            Building tomorrow's leaders with knowledge, character, and faith.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <button
              onClick={() => onNavigate('admission')}
              className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-all duration-300 transform hover:scale-105 flex items-center gap-2"
            >
              Apply for Admission
              <ArrowRight className="h-5 w-5" />
            </button>
            
            <button
              onClick={() => onNavigate('about')}
              className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-gray-900 transition-all duration-300"
            >
              Learn More
            </button>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-6 border border-white border-opacity-20">
              <Users className="h-8 w-8 text-green-400 mx-auto mb-3" />
              <div className="text-3xl font-bold mb-2">500+</div>
              <div className="text-lg">Students</div>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-6 border border-white border-opacity-20">
              <BookOpen className="h-8 w-8 text-green-400 mx-auto mb-3" />
              <div className="text-3xl font-bold mb-2">25+</div>
              <div className="text-lg">Expert Teachers</div>
            </div>
            
            <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-lg p-6 border border-white border-opacity-20">
              <Award className="h-8 w-8 text-green-400 mx-auto mb-3" />
              <div className="text-3xl font-bold mb-2">15+</div>
              <div className="text-lg">Years of Excellence</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;